# Cache Detector
